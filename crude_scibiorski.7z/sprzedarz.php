<link rel="stylesheet" href="styl.css">
<?php
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_scibiorski");
 
$kwerenda="SELECT * from sprzedarz";
echo "<main>";
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->id_sprzedarzy . ";" . $rzad->produkt . ";" . $rzad->data_zakupu . ";" . $rzad->ilosc . ";" . $rzad->znizka . "<br/>";
    }
}
echo "</main>";
$poloczenie->close();
?>
