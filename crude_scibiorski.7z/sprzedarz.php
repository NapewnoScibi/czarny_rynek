<link rel="stylesheet" href="styl.css">
<?php
// utworzenie polaczenia
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_napojow");
// sprawdzenie czy istnieja dane do wprowadzenia i utworzenie kwerendy do bazy danych
if(isset($_POST["produkt"]) && isset($_POST["data_zakupu"]) && isset($_POST["ilosc"]) && isset($_POST["znizka"]))
{
    $kwerenda = "INSERT into sprzedarz (id_sprzedarzy, produkt, data_zakupu, ilosc, znizka) values (null,'".$_POST["produkt"]."','".$_POST["data_zakupu"]."','".$_POST["ilosc"]."','".$_POST["znizka"]."');";
    echo $kwerenda . "<br>";
    $wynik=$poloczenie->query($kwerenda);
    echo $wynik;
}
 // zmiana na kwerende wybierajaca
$kwerenda="SELECT * from sprzedarz";
// wypisanie <main> jako glowny kontener strony
echo "<main>";
// wypisanie elementow bazy danych
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->id_sprzedarzy . ";" . $rzad->produkt . ";" . $rzad->data_zakupu . ";" . $rzad->ilosc . ";" . $rzad->znizka . "<br/>";
    }
}
// utworzenie formularza do dopisania do bazy danych
echo "<form method='POST' action='sprzedarz.php'>". PHP_EOL .
"<label>produkt<input type='text' name='produkt'></label><br>" . PHP_EOL .
"<label>data zakupu<input type='date' name='data_zakupu'></label><br>" . PHP_EOL .
"<label>ilosc<input type='number' name='ilosc'></label><br>" . PHP_EOL .
"<label>znizka<input type='number' name='znizka'></label><br>" . PHP_EOL .
"<button type='submit'>dodaj</button><br>". PHP_EOL .
"</form>";
// zamkniecie <main>
echo "</main>";
// zamkniecie polaczenia z baza danych
$poloczenie->close();
?>
