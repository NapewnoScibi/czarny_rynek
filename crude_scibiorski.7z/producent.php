<link rel="stylesheet" href="styl.css">
<?php
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_scibiorski");
 
$kwerenda="SELECT * from producent";
echo "<main>";
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->producent_id . ";" . $rzad->nazwa_firmy . ";" . $rzad->kraj_firmy . ";" . $rzad->siedziba_firmy . "<br/>";
    }
}
echo "</main>";
$poloczenie->close();
?>
