<link rel="stylesheet" href="styl.css">
<?php
// utworzenie polaczenia
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_napojow");
// sprawdzenie czy istnieja dane do wprowadzenia i utworzenie kwerendy do bazy danych
if(isset($_POST["nazwa_firmy"]) && isset($_POST["kraj_firmy"]) && isset($_POST["siedziba_firmy"]))
{
    $kwerenda = "INSERT into producent (producent_id, nazwa_firmy, kraj_firmy, siedziba_firmy) values (null,'".$_POST["nazwa_firmy"]."','".$_POST["kraj_firmy"]."','".$_POST["siedziba_firmy"]."');";
    echo $kwerenda . "<br>";
    $wynik=$poloczenie->query($kwerenda);
    echo $wynik;
}
 // zmiana na kwerende wybierajaca
$kwerenda="SELECT * from producent";
// wypisanie <main> jako glowny kontener strony
echo "<main>";
// wypisanie elementow bazy danych
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->producent_id . ";" . $rzad->nazwa_firmy . ";" . $rzad->kraj_firmy . ";" . $rzad->siedziba_firmy . "<br/>";
    }
}
// utworzenie formularza do dopisania do bazy danych
echo "<form method='POST' action='producent.php'>". PHP_EOL .
"<label>nazwa_firmy<input type='text' name='nazwa_firmy'></label><br>" . PHP_EOL .
"<label>kraj firmy<input type='text' name='kraj_firmy'></label><br>" . PHP_EOL .
"<label>siedziba_firmy<input type='text' name='siedziba_firmy'></label><br>" . PHP_EOL .
"<button type='submit'>dodaj</button><br>". PHP_EOL .
"</form>";

echo "</main>";
echo "</main>";
$poloczenie->close();
?>
