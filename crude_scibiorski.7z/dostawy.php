<link rel="stylesheet" href="styl.css">
<?php
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_scibiorski");
 
$kwerenda="SELECT * from dostawy";
echo "<main>";
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->id_dostawy . ";" . $rzad->towar . ";" . $rzad->data_zamowienia . ";" . $rzad->data_przyjazdu . ";" . $rzad->ilosc_towaru . ";" . $rzad->koszt_dostawy. "<br/>";
    }
}
echo "</main>";
$poloczenie->close();
?>
