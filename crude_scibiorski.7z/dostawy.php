<link rel="stylesheet" href="styl.css">
<?php
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_napojow");
 
$kwerenda="SELECT * from dostawy";
echo "<main>";
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->id_dostawy . ";" . $rzad->towar . ";" . $rzad->data_zamowienia . ";" . $rzad->data_przyjazdu . ";" . $rzad->ilosc_towaru . ";" . $rzad->koszt_dostawy. "<br/>";
    }
}
echo "<form method='POST' action='dostawy.php'>". PHP_EOL .
"<label>towar<input type='text' name='towar'></label><br>" . PHP_EOL .
"<label>data zamowienia<input type='date' name='data_zamowienia'></label><br>" . PHP_EOL .
"<label>data_przyjazdu<input type='date' name='data_przyjazdu'></label><br>" . PHP_EOL .
"<label>ilosc_towaru<input type='number' name='ilosc_towaru'></label><br>" . PHP_EOL .
"<label>koszt_dostawy<input type='number' name='koszt_dostawy'></label><br>" . PHP_EOL .
"<button type='submit'>dodaj</button><br>". PHP_EOL .
"</form>";
if(isset($_POST["towar"]) && isset($_POST["data_zamowienia"]) && isset($_POST["data_przyjazdu"]) && isset($_POST["ilosc_towaru"]) && isset($_POST["koszt_dostawy"]))
{
    $kwerenda = "INSERT into dostawy (id_dostawy , towar, data_zamowienia, data_przyjazdu, ilosc_towaru, koszt_dostawy) values (null,'".$_POST["towar"]."','".$_POST["data_zamowienia"]."','".$_POST["data_przyjazdu"]."','".$_POST["ilosc_towaru"]."','".$_POST["koszt_dostawy"]."');";
    echo $kwerenda . "<br>";
    $wynik=$poloczenie->query($kwerenda);
    echo $wynik;
}
echo "</main>";
$poloczenie->close();
?>
