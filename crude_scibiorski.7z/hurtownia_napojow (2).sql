-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Paź 10, 2024 at 09:15 AM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hurtownia_napojow`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dostawy`
--

CREATE TABLE `dostawy` (
  `id_dostawy` int(11) NOT NULL,
  `towar` int(11) NOT NULL,
  `data_zamowienia` date NOT NULL,
  `data_przyjazdu` date NOT NULL,
  `ilosc_towaru` int(11) NOT NULL,
  `koszt_dostawy` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `dostawy`
--

INSERT INTO `dostawy` (`id_dostawy`, `towar`, `data_zamowienia`, `data_przyjazdu`, `ilosc_towaru`, `koszt_dostawy`) VALUES
(1, 6, '2024-10-02', '2024-10-04', 200, 1200),
(2, 7, '2024-10-03', '2024-10-07', 100, 600),
(3, 7, '2024-10-02', '0000-00-00', 100, 3),
(4, 7, '2024-10-02', '0000-00-00', 100, 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `producent`
--

CREATE TABLE `producent` (
  `producent_id` int(11) NOT NULL,
  `nazwa_firmy` varchar(50) NOT NULL,
  `kraj_firmy` varchar(50) NOT NULL,
  `siedziba_firmy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `producent`
--

INSERT INTO `producent` (`producent_id`, `nazwa_firmy`, `kraj_firmy`, `siedziba_firmy`) VALUES
(1, 'Tymbark', 'Polska', 'Krakow'),
(2, 'Coca Cola', 'USA', 'Atlanta'),
(3, 'fajna firma', 'Polska', 'Gdansk'),
(4, 'fajna firma', 'Polska', 'Gdansk'),
(5, 'cosdsadsa', 'Niemdcy', 'Berlin');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sprzedarz`
--

CREATE TABLE `sprzedarz` (
  `id_sprzedarzy` int(11) NOT NULL,
  `produkt` int(11) NOT NULL,
  `data_zakupu` date NOT NULL,
  `ilosc` int(11) NOT NULL,
  `znizka` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `sprzedarz`
--

INSERT INTO `sprzedarz` (`id_sprzedarzy`, `produkt`, `data_zakupu`, `ilosc`, `znizka`) VALUES
(1, 7, '2024-10-09', 321, 0),
(2, 6, '2024-10-01', 100, 10),
(6, 6, '2024-10-04', 100, 30),
(7, 7, '2024-10-04', 10, 1),
(8, 7, '2024-10-04', 10, 1),
(9, 7, '2024-10-04', 10, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `towary`
--

CREATE TABLE `towary` (
  `towar_id` int(11) NOT NULL,
  `nazwa` varchar(50) NOT NULL,
  `cena` double NOT NULL,
  `opis` text NOT NULL,
  `producent` int(50) NOT NULL,
  `w_magazynie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `towary`
--

INSERT INTO `towary` (`towar_id`, `nazwa`, `cena`, `opis`, `producent`, `w_magazynie`) VALUES
(6, 'Tymbark wisnia', 2, 'Wiśniowe', 1, 300),
(7, 'Coca cola', 3, 'Gazowane', 2, 1000),
(8, '', 2, 'fajna', 3, 100),
(9, 'Woda', 2, 'fajna', 3, 100),
(10, 'Pepsi', 4, 'cos', 1, 999),
(11, 'Pepsi', 4, 'cos', 1, 999);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `dostawy`
--
ALTER TABLE `dostawy`
  ADD PRIMARY KEY (`id_dostawy`),
  ADD KEY `dostawy_ibfk_1` (`towar`);

--
-- Indeksy dla tabeli `producent`
--
ALTER TABLE `producent`
  ADD PRIMARY KEY (`producent_id`);

--
-- Indeksy dla tabeli `sprzedarz`
--
ALTER TABLE `sprzedarz`
  ADD PRIMARY KEY (`id_sprzedarzy`),
  ADD KEY `produkt` (`produkt`);

--
-- Indeksy dla tabeli `towary`
--
ALTER TABLE `towary`
  ADD PRIMARY KEY (`towar_id`),
  ADD KEY `producent` (`producent`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dostawy`
--
ALTER TABLE `dostawy`
  MODIFY `id_dostawy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `producent`
--
ALTER TABLE `producent`
  MODIFY `producent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sprzedarz`
--
ALTER TABLE `sprzedarz`
  MODIFY `id_sprzedarzy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `towary`
--
ALTER TABLE `towary`
  MODIFY `towar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dostawy`
--
ALTER TABLE `dostawy`
  ADD CONSTRAINT `dostawy_ibfk_1` FOREIGN KEY (`towar`) REFERENCES `towary` (`towar_id`);

--
-- Constraints for table `sprzedarz`
--
ALTER TABLE `sprzedarz`
  ADD CONSTRAINT `sprzedarz_ibfk_1` FOREIGN KEY (`produkt`) REFERENCES `towary` (`towar_id`);

--
-- Constraints for table `towary`
--
ALTER TABLE `towary`
  ADD CONSTRAINT `towary_ibfk_1` FOREIGN KEY (`producent`) REFERENCES `producent` (`producent_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
