<link rel="stylesheet" href="styl.css">
<?php
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_scibiorski");
 
$kwerenda="SELECT * from towary";
echo "<main>";
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->towar_id . ";" . $rzad->nazwa . ";" . $rzad->cena . ";" . $rzad->opis . ";" . $rzad->producent . ";" . $rzad->w_magazynie. "<br/>";
    }
}
echo "</main>";
$poloczenie->close();
?>
