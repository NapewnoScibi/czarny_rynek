<link rel="stylesheet" href="styl.css">
<?php
$poloczenie = new mysqli("127.0.0.1","root","","hurtownia_napojow");
 
$kwerenda="SELECT * from towary";
echo "<main>";
if($wynik=$poloczenie->query($kwerenda))
{
    while($rzad=$wynik->fetch_object())
    {
        echo $rzad->towar_id . ";" . $rzad->nazwa . ";" . $rzad->cena . ";" . $rzad->opis . ";" . $rzad->producent . ";" . $rzad->w_magazynie. "<br/>";
    }
}
echo "<form method='POST' action='towary.php'>". PHP_EOL .
"<label>nazwa<input type='text' name='nazwa'></label><br>" . PHP_EOL .
"<label>cena<input type='number' name='cena'></label><br>" . PHP_EOL .
"<label>opis<input type='text' name='opis'></label><br>" . PHP_EOL .
"<label>producent<input type='number' name='producent'></label><br>" . PHP_EOL .
"<label>w_magazynie<input type='number' name='w_magazynie'></label><br>" . PHP_EOL .
"<button type='submit'>dodaj</button><br>". PHP_EOL .
"</form>";
if(isset($_POST["nazwa"]) && isset($_POST["cena"]) && isset($_POST["opis"]) && isset($_POST["producent"]) && isset($_POST["w_magazynie"]))
{
    $kwerenda = "INSERT into towary (towar_id , nazwa, cena, opis, producent, w_magazynie) values (null,'".$_POST["nazwa"]."','".$_POST["cena"]."','".$_POST["opis"]."','".$_POST["producent"]."','".$_POST["w_magazynie"]."');";
    echo $kwerenda . "<br>";
    $wynik=$poloczenie->query($kwerenda);
    echo $wynik;
}
echo "</main>";
$poloczenie->close();
?>
